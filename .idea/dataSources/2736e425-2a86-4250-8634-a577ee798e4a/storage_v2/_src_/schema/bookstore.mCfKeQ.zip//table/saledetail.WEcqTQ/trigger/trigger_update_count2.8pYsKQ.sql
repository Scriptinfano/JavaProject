create definer = root@localhost trigger trigger_update_count2
    after insert
    on saledetail
    for each row
begin
    update bookstore.book
    set count=count-new.book_count
    where id=new.book_id;
end;

