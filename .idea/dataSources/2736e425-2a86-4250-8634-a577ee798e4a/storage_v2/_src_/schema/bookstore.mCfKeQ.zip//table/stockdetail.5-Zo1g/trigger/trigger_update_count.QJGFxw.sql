create definer = root@localhost trigger trigger_update_count
    after insert
    on stockdetail
    for each row
begin
    update bookstore.book
    set count=count+new.stock_count
    where id=new.book_id;
end;

