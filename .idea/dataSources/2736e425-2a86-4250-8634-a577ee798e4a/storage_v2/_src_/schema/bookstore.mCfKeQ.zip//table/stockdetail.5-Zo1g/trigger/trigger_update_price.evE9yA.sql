create definer = root@localhost trigger trigger_update_price
    after insert
    on stockdetail
    for each row
begin
    update bookstore.book
        set purchase_price=new.stock_price
    where id=new.book_id;
end;

