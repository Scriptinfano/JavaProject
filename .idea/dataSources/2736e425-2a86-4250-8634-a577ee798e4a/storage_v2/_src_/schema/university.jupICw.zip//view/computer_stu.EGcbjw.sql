create definer = root@localhost view computer_stu as
select `university`.`s`.`SNo` AS `sno`, `university`.`s`.`SN` AS `sn`, `university`.`sc`.`CNo` AS `cno`
from `university`.`s`
         join `university`.`sc`
where ((`university`.`s`.`SNo` = `university`.`sc`.`SNo`) and (`university`.`s`.`Dept` = '计算机'));

-- comment on column computer_stu.sno not supported: 学生学号

-- comment on column computer_stu.sn not supported: 学生姓名

-- comment on column computer_stu.cno not supported: 课程号

