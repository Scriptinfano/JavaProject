create definer = root@localhost view computer_stu2 as
select `university`.`s`.`SNo` AS `sno`, `university`.`s`.`SN` AS `sn`, `university`.`sc`.`CNo` AS `cno`, `university`.`tc`.`TNo` AS `tno`
from `university`.`s`
         join `university`.`sc`
         join `university`.`tc`
where ((`university`.`s`.`SNo` = `university`.`sc`.`SNo`) and (`university`.`sc`.`CNo` = `university`.`tc`.`CNo`) and (`university`.`s`.`Dept` = '计算机'));

-- comment on column computer_stu2.sno not supported: 学生学号

-- comment on column computer_stu2.sn not supported: 学生姓名

-- comment on column computer_stu2.cno not supported: 课程号

-- comment on column computer_stu2.tno not supported: 教师编号

