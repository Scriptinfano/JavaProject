create definer = root@localhost trigger salary_check_trigger
    before insert
    on employee
    for each row
begin
    /*declare @temp_dno varchar(10);
    declare @manager_salary int;
    declare @employee_salary int;*/
    set @temp_dno=(select dno from profession where pno=new.pno);
    set @manager_salary= (select salary from profession where dno=@temp_dno);
    set @employee_salary=(select salary from profession where pno=new.pno);
    if  @employee_salary > @manager_salary then
        signal sqlstate 'HY000' set message_text ='薪资高于领导的薪资';
    end if;
end;

