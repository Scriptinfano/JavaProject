create
    definer = root@localhost procedure myProcedure()
BEGIN
    DECLARE myVariable INT DEFAULT 10;
    SET myVariable = myVariable + 5;
    SELECT myVariable;
END;

