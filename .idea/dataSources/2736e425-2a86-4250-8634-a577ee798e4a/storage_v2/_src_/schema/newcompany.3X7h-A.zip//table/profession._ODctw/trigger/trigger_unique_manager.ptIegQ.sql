create definer = root@localhost trigger trigger_unique_manager
    before insert
    on profession
    for each row
begin
  if '1'= any (select is_supervisor where dno=NEW.dno) and NEW.is_supervisor='1' then
      signal sqlstate 'HY000' set message_text ='同一个部门不能有两个管理者';
  end if;

  set @ceo_dno=(select dno from department where dn='管理部');
  set @ceo_salary= (select salary from profession where dno=@ceo_dno and is_supervisor='1');
  if  NEW.salary > @ceo_salary then
      signal sqlstate 'HY000' set message_text ='薪资高于领导的薪资';
  end if;
end;

