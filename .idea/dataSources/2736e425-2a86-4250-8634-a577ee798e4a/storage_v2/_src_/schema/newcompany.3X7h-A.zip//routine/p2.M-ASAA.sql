create
    definer = root@localhost procedure p2(OUT count_stu int)
begin

    set @stu_count = 100;
    select count(*) into @stu_count from newcompany.profession;
    set count_stu = @stu_count;
end;

