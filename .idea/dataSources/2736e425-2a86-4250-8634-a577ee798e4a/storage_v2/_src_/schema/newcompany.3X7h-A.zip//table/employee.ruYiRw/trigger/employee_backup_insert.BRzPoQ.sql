create definer = root@localhost trigger employee_backup_insert
    after insert
    on employee
    for each row
begin
    insert into employee_backup values (new.eno, new.eid, new.en, new.sex, new.age, new.phone, new.pno);
end;

