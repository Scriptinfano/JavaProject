create definer = root@localhost view merchant_view as
select `newbookstore`.`wholesaler`.`wholesalerId` AS `批发商id`, `newbookstore`.`wholesaler`.`wholesalerName` AS `批发商名字`, `newbookstore`.`wholesaler`.`wholesalerTel` AS `批发商电话号码`, `newbookstore`.`wholesaler`.`wholesalerContext` AS `批发商备注`
from `newbookstore`.`wholesaler`;

-- comment on column merchant_view.批发商id not supported: 批发商编号

-- comment on column merchant_view.批发商名字 not supported: 批发商名称

-- comment on column merchant_view.批发商电话号码 not supported: 批发商电话号码

-- comment on column merchant_view.批发商备注 not supported: 批发商描述

