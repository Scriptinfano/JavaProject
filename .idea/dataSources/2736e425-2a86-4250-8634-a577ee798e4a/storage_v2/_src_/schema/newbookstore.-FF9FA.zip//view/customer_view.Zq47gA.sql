create definer = root@localhost view customer_view as
select `newbookstore`.`customer`.`customerId` AS `客户id`, `newbookstore`.`customer`.`customerName` AS `客户姓名`, `newbookstore`.`customer`.`customerTel` AS `客户电话号码`, `newbookstore`.`customer`.`customerContext` AS `客户备注`
from `newbookstore`.`customer`;

-- comment on column customer_view.客户id not supported: 顾客编号

-- comment on column customer_view.客户姓名 not supported: 顾客名

-- comment on column customer_view.客户电话号码 not supported: 顾客电话号码

-- comment on column customer_view.客户备注 not supported: 备注

