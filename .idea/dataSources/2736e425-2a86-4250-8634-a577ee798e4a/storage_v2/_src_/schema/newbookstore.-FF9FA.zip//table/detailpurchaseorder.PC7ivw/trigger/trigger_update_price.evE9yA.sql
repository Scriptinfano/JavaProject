create definer = root@localhost trigger trigger_update_price
    after insert
    on detailpurchaseorder
    for each row
begin
    update NewBookStore.bookinfo
    set purchasePrice=new.purchasePrice
    where bookId = new.bookId;
end;

