create
    definer = root@localhost procedure inputWholesaler(IN theName varchar(20), IN theContact varchar(11), IN theContext varchar(20))
begin
    insert into NewBookStore.wholesaler(wholesalerName, wholesalerTel, wholesalerContext) values (theName, theContact, theContext);
end;

