create definer = root@localhost view booksale_view as
select `newbookstore`.`bookinfo`.`bookId` AS `bookId`, `newbookstore`.`bookinfo`.`bookName` AS `bookName`, `newbookstore`.`bookinfo`.`bookPrice` AS `bookPrice`, `newbookstore`.`bookinfo`.`bookInventory` AS `bookInventory`
from `newbookstore`.`bookinfo`;

-- comment on column booksale_view.bookId not supported: 图书编号

-- comment on column booksale_view.bookName not supported: 图书名称

-- comment on column booksale_view.bookPrice not supported: 售价

-- comment on column booksale_view.bookInventory not supported: 库存

