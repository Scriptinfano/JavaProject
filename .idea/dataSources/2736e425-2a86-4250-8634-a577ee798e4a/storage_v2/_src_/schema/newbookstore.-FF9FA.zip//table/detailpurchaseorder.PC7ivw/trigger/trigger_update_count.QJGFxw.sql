create definer = root@localhost trigger trigger_update_count
    after insert
    on detailpurchaseorder
    for each row
begin
    update NewBookStore.bookinfo
    set bookInventory=bookinfo.bookInventory + new.orderNum
    where bookId = new.bookId;
end;

