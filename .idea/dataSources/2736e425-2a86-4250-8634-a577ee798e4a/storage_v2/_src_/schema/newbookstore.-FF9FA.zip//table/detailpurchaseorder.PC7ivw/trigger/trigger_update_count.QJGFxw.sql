create definer = root@localhost trigger trigger_update_count
    after insert
    on detailpurchaseorder
    for each row
begin
    update NewBookStore.bookinfo
    set inventory=bookinfo.inventory + new.orderNum
    where bookId = new.bookId;
end;

