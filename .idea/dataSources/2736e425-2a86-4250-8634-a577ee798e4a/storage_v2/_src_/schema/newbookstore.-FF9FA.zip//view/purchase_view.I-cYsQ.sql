create definer = root@localhost view purchase_view as
select `newbookstore`.`purchaseorder`.`purchaseOrderId` AS `进货订单号`, `newbookstore`.`bookinfo`.`bookName` AS `书名`, `newbookstore`.`detailpurchaseorder`.`purchasePrice` AS `进货进货单价`, `newbookstore`.`purchaseorder`.`orderDate` AS `进货日期`, `newbookstore`.`detailpurchaseorder`.`purchaseTotalPrice` AS `进货总价`, `newbookstore`.`detailpurchaseorder`.`orderNum` AS `进货总数`
from `newbookstore`.`purchaseorder`
         join `newbookstore`.`detailpurchaseorder`
         join `newbookstore`.`bookinfo`
where ((`newbookstore`.`purchaseorder`.`purchaseOrderId` = `newbookstore`.`detailpurchaseorder`.`purchaseOrderId`) and (`newbookstore`.`detailpurchaseorder`.`bookId` = `newbookstore`.`bookinfo`.`bookId`));

-- comment on column purchase_view.进货订单号 not supported: 进货单号

-- comment on column purchase_view.书名 not supported: 图书名称

-- comment on column purchase_view.进货进货单价 not supported: 进货单价

-- comment on column purchase_view.进货日期 not supported: 下单日期

-- comment on column purchase_view.进货总价 not supported: 进货总价

-- comment on column purchase_view.进货总数 not supported: 进货数量

