create definer = root@localhost view sale_view as
select `newbookstore`.`salesorder`.`salesOrderId` AS `订单号`, `newbookstore`.`bookinfo`.`bookName` AS `书名`, `newbookstore`.`bookinfo`.`context` AS `备注`, `newbookstore`.`bookinfo`.`price` AS `单价`, `newbookstore`.`salesorder`.`salesDate` AS `售卖日期`, `newbookstore`.`detailsalesorder`.`salesPrice` AS `销售总价`, `newbookstore`.`detailsalesorder`.`salesNum` AS `售出数量`
from `newbookstore`.`salesorder`
         join `newbookstore`.`detailsalesorder`
         join `newbookstore`.`bookinfo`
where ((`newbookstore`.`salesorder`.`salesOrderId` = `newbookstore`.`detailsalesorder`.`salesOrderId`) and (`newbookstore`.`detailsalesorder`.`bookId` = `newbookstore`.`bookinfo`.`bookId`));

-- comment on column sale_view.订单号 not supported: 销售单号

-- comment on column sale_view.书名 not supported: 图书名称

-- comment on column sale_view.备注 not supported: 描述

-- comment on column sale_view.单价 not supported: 售价

-- comment on column sale_view.售卖日期 not supported: 销售日期

-- comment on column sale_view.销售总价 not supported: 详单的总价

-- comment on column sale_view.售出数量 not supported: 销售该书的数量

