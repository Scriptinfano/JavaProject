create definer = root@localhost view sale_view as
select `newbookstore`.`salesorder`.`salesOrderId` AS `销售订单号`, `newbookstore`.`bookinfo`.`bookName` AS `书名`, `newbookstore`.`bookinfo`.`bookPrice` AS `单价`, `newbookstore`.`salesorder`.`salesDate` AS `售卖日期`, `newbookstore`.`detailsalesorder`.`salesPrice` AS `销售总价`, `newbookstore`.`detailsalesorder`.`salesNum` AS `售出数量`
from `newbookstore`.`salesorder`
         join `newbookstore`.`detailsalesorder`
         join `newbookstore`.`bookinfo`
where ((`newbookstore`.`salesorder`.`salesOrderId` = `newbookstore`.`detailsalesorder`.`salesOrderId`) and (`newbookstore`.`detailsalesorder`.`bookId` = `newbookstore`.`bookinfo`.`bookId`));

-- comment on column sale_view.销售订单号 not supported: 销售单号

-- comment on column sale_view.书名 not supported: 图书名称

-- comment on column sale_view.单价 not supported: 售价

-- comment on column sale_view.售卖日期 not supported: 销售日期

-- comment on column sale_view.销售总价 not supported: 详单的总价

-- comment on column sale_view.售出数量 not supported: 销售该书的数量

