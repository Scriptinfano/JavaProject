create definer = root@localhost trigger trigger_update_count2
    after insert
    on detailsalesorder
    for each row
begin
    update NewBookStore.bookinfo
    set bookInventory=bookinfo.bookInventory - new.salesNum
    where bookId = new.bookId;
end;

