create
    definer = root@localhost procedure createSaleOrder(IN theCustomerId int, IN theDate datetime, IN theContext varchar(20))
begin
    insert into NewBookStore.salesorder(salesDate, customerId, context) values (theDate, theCustomerId, theContext);
end;

