create
    definer = root@localhost procedure createSaleView(IN theSaleId int)
begin
    select bookName         as '书名',
           bookInfo.context as '备注',
           price            as '单价',
           salesDate        as '售卖日期',
           salesPrice       as '销售总价',
           salesNum         as '售出数量'
    from salesorder,
         detailSalesOrder,
         bookInfo
    where salesOrder.salesOrderId = detailSalesOrder.salesOrderId
      and detailSalesOrder.bookId = bookInfo.bookId
      and salesOrder.salesOrderId = theSaleId;
end;

