create definer = root@localhost trigger trigger_updateInoutLog_purchase
    after insert
    on detailpurchaseorder
    for each row
begin
    declare theDate datetime;
    select orderDate into theDate from purchaseorder where purchaseOrderId = new.purchaseOrderId;
    insert into NewBookStore.inoutschedule(inoutMark, bookId, bookCount, financeChange, operateDate) values (1, new.bookId, new.orderNum, 0 - new.purchaseTotalPrice, theDate);
end;

