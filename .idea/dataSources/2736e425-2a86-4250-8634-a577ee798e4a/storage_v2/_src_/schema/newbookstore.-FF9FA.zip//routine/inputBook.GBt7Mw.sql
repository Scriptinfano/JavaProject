create
    definer = root@localhost procedure inputBook(IN theName varchar(20), IN theAuthor varchar(20), IN theType varchar(20), IN thePublisherName varchar(20))
begin
    insert into NewBookStore.bookinfo(bookName, author, bookType, publisherName) values (theName, theAuthor, theType, thePublisherName);
end;

