create
    definer = root@localhost procedure createPurchaseOrder(IN merchantId int, IN theDate datetime, IN theContext varchar(20))
begin
    insert into NewBookStore.purchaseorder(orderDate, wholesalerId, context) values (theDate, merchantId, theContext);
end;

