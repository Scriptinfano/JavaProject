create definer = root@localhost view bookpurchase_view as
select `newbookstore`.`bookinfo`.`bookId` AS `bookId`, `newbookstore`.`bookinfo`.`bookName` AS `bookName`
from `newbookstore`.`bookinfo`;

-- comment on column bookpurchase_view.bookId not supported: 图书编号

-- comment on column bookpurchase_view.bookName not supported: 图书名称

