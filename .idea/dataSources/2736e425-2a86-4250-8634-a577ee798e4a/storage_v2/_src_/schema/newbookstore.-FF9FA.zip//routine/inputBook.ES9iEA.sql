create
    definer = root@localhost procedure inputBook(IN theName varchar(20), IN theAuthor varchar(20), IN theType varchar(20), IN thePublisherName varchar(20), IN theContext varchar(100))
begin
    insert into NewBookStore.bookinfo(bookName, bookAuthor, bookType, bookPublisher,bookContext) values (theName, theAuthor, theType, thePublisherName,theContext);
end;

