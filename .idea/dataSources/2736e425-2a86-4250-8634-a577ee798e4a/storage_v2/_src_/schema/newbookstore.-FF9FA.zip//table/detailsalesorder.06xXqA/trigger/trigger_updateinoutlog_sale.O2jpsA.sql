create definer = root@localhost trigger trigger_updateInoutLog_sale
    after insert
    on detailsalesorder
    for each row
begin
    declare theDate datetime;
    select salesDate into theDate from salesorder where salesOrderId = new.salesOrderId;
    insert into NewBookStore.inoutschedule(inoutMark, bookId, bookCount, financeChange, operateDate) values (0, new.bookId, new.salesNum, new.salesPrice, theDate);
end;

