create
    definer = root@localhost procedure updateSaleOrder(IN theSalesOrderId int)
begin
    declare theTotalPrice float;
    select sum(salesPrice) into theTotalPrice from detailsalesorder where salesOrderId = theSalesOrderId;
    update NewBookStore.salesorder set totalPrice=theTotalPrice where salesOrderId = theSalesOrderId;
end;

