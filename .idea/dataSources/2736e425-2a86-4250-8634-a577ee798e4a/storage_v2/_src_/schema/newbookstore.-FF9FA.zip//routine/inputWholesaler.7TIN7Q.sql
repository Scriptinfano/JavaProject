create
    definer = root@localhost procedure inputWholesaler(IN theName varchar(20), IN theContact varchar(11))
begin
    insert into NewBookStore.wholesaler(wholesalerName, wholesalerTel) values (theName, theContact);
end;

