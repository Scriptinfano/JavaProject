create
    definer = root@localhost procedure selectInoutSchedule_in(IN dateBegin datetime, IN dateEnd datetime)
begin
    SELECT *
    FROM newbookstore.inoutschedule
    WHERE operateDate BETWEEN dateBegin AND dateEnd and inoutMark=1;
end;

