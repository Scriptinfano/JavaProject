create definer = root@localhost view bookinfo_view as
select `newbookstore`.`bookinfo`.`bookId`            AS `书籍id`,
       `newbookstore`.`bookinfo`.`bookName`          AS `书名`,
       `newbookstore`.`bookinfo`.`bookType`          AS `书籍类型`,
       `newbookstore`.`bookinfo`.`bookAuthor`        AS `书籍作者`,
       `newbookstore`.`bookinfo`.`bookPublisher`     AS `书籍出版商`,
       `newbookstore`.`bookinfo`.`bookContext`       AS `书籍备注`,
       `newbookstore`.`bookinfo`.`bookPrice`         AS `售价`,
       `newbookstore`.`bookinfo`.`bookPurchasePrice` AS `进价`,
       `newbookstore`.`bookinfo`.`bookInventory`     AS `库存`
from `newbookstore`.`bookinfo`;

-- comment on column bookinfo_view.书籍id not supported: 图书编号

-- comment on column bookinfo_view.书名 not supported: 图书名称

-- comment on column bookinfo_view.书籍类型 not supported: 图书类别

-- comment on column bookinfo_view.书籍作者 not supported: 作者

-- comment on column bookinfo_view.书籍出版商 not supported: 出版社

-- comment on column bookinfo_view.书籍备注 not supported: 描述

-- comment on column bookinfo_view.售价 not supported: 售价

-- comment on column bookinfo_view.进价 not supported: 进价

-- comment on column bookinfo_view.库存 not supported: 库存

