create
    definer = root@localhost procedure updateSalePrice(IN theBookId int, IN thePrice float)
begin
    update NewBookStore.bookinfo
    set price=thePrice
    where bookId = theBookId;
end;

