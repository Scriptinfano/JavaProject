create
    definer = root@localhost procedure editMerchant(IN theMerchantId int, IN theContext varchar(100), IN theName varchar(20), IN theTel varchar(11))
begin
    update NewBookStore.wholesaler
    set wholesalerContext=theContext,wholesalerName=theName,wholesalerTel=theTel
    where wholesalerId = theMerchantId;
end;

