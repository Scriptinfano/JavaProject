create
    definer = root@localhost procedure selectInoutSchedule_out(IN dateBegin datetime, IN dateEnd datetime)
begin
    SELECT *
    FROM newbookstore.inoutschedule
    WHERE operateDate BETWEEN dateBegin AND dateEnd and inoutMark=0;
end;

