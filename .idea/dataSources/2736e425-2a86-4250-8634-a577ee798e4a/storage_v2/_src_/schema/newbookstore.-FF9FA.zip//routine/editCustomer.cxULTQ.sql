create
    definer = root@localhost procedure editCustomer(IN theCustomerId int, IN theContext varchar(100), IN theName varchar(20), IN theTel varchar(11))
begin
    update NewBookStore.customer
    set customerContext=theContext,customerName=theName,customerTel=theTel
    where customerId = theCustomerId;
end;

