create
    definer = root@localhost procedure editBook(IN theBookId int, IN theBookName varchar(20), IN theBookType varchar(20), IN theBookAuthor varchar(20), IN theBookPublisher varchar(20), IN theContext varchar(100))
begin
    update NewBookStore.bookinfo
    set bookContext=theContext,
        bookPublisher=theBookPublisher,
        bookAuthor=theBookAuthor,
        bookType=theBookType,
        bookName=theBookName
    where bookId = theBookId;
end;

