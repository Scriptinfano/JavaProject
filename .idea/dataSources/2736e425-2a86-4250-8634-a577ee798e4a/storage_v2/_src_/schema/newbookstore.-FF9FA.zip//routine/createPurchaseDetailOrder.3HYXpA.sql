create
    definer = root@localhost procedure createPurchaseDetailOrder(IN thePurchaseId int, IN theBookId int, IN theOrderNum int, IN thePrice float)
begin
    declare totalPrice float;
    set totalPrice = theOrderNum * thePrice;
    insert into NewBookStore.detailpurchaseorder(purchaseOrderId, bookId, OrderNum, purchasePrice, purchaseTotalPrice) values (thePurchaseId, theBookId, theOrderNum, thePrice, totalPrice);
end;

