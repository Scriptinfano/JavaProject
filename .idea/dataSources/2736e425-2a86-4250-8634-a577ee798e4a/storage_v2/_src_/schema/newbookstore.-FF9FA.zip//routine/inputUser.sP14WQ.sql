create
    definer = root@localhost procedure inputUser(IN theName varchar(20), IN thePhoneNum varchar(11), IN theContext varchar(20))
begin
    insert into NewBookStore.customer(customerName, customerPhoneNumber, customerContext) values (theName, thePhoneNum, theContext);
end;

