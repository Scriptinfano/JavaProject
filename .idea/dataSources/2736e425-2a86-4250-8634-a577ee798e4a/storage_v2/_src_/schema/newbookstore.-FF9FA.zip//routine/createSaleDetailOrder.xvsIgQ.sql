create
    definer = root@localhost procedure createSaleDetailOrder(IN theSaleId int, IN theBookId int, IN theBookCount int)
begin
    declare thePrice float;
    declare theTotalPrice float;

    select bookPrice into thePrice from NewBookStore.bookinfo where bookId = theBookId;
    set theTotalPrice = thePrice * theBookCount;

    insert into NewBookStore.detailsalesorder(salesOrderId, bookId, salesNum, bookPrice, salesPrice) values (theSaleId, theBookId, theBookCount, thePrice, theTotalPrice);
end;

